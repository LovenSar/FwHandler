# MT29F8G08ABABA BCH16 recovery package

This package contains a standalone extractor for the recovered controller
layout used by the supplied MT29F8G08ABABA dump. It is not a general-purpose
replacement for FwHandler's datasheet-based `4096 + 224` OOB profile.

The script requires Python 3.8 or newer and uses only the standard library.
It expects the complete 1,132,462,080-byte dump in the controller-specific
layout described in `RECOVERY_NOTES.md`. The original dump and extracted
firmware files are not included.

Run a full ECC scan, directory parse, and file extraction with:

```bash
python3 unpack_mt29f8g08.py dump.bin -o unpacked --ecc --dir --all
```

On the supplied dump, the BCH16 scan corrected 9,018 sectors and 9,074 data or
ECC bits, with zero unrepairable sectors. The first sector on each page is
included. Its BCH message consists of the 10-byte page header followed by the
512-byte data sector.

The scan extracted 1,876 ELF files, 1,544 PNG files, 223 gzip files, 27 ZIP
files, 80 XML files, and 15 SQLite databases. Some detected file starts did
not pass complete-file validation. See `RECOVERY_NOTES.md` for the detailed
counts and limitations.
